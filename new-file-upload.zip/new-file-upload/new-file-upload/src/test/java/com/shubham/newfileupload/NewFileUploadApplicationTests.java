package com.shubham.newfileupload;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewFileUploadApplicationTests {

	@Test
	void contextLoads() {
	}

}
