package com.shubham.newfileupload.service;

import java.io.IOException;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.shubham.newfileupload.entity.File;

public interface FileService {
	public void saveFile(MultipartFile file) throws IOException;
	public List<File> getAllFiles();
	public List<File> searchFiles(String keyword);
	public byte[] downloadFile(Long fileId) throws IOException;
}
