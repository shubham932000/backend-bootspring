package com.shubham.newfileupload.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.shubham.newfileupload.entity.File;
import com.shubham.newfileupload.exception.FileStorageException;
import com.shubham.newfileupload.repository.FileRepository;

@Service
public class FileServiceImpl implements FileService{
	
	 @Autowired
	 private FileRepository fileRepository;

	@Override
	public void saveFile(MultipartFile multipartFile) throws IOException {
		// Save file details to the database
		File file = new File();
		file.setFileName(multipartFile.getOriginalFilename());
		file.setFilePath("C:/Users/ssv93/Downloads/" + multipartFile.getOriginalFilename()); // Set your file storage path
		fileRepository.save(file);
	}

	@Override
	public List<File> getAllFiles() {
		// TODO Auto-generated method stub
		return fileRepository.findAll();	}

	@Override
	public List<File> searchFiles(String keyword) {
		// TODO Auto-generated method stub
        return fileRepository.findByFileNameContainingIgnoreCase(keyword);
	}
	 public byte[] downloadFile(Long fileId) throws IOException {
	        // Replace this path with the actual path where your files are stored
	        String filePath = "C:/Users/ssv93/Downloads/";
	        
	        File fileEntity = fileRepository.findById(fileId)
	                .orElseThrow();

	        Path path = Paths.get(filePath + fileEntity.getFileName());
	        return Files.readAllBytes(path);
	    }

}
